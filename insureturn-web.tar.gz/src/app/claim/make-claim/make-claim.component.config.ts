export const claimDialogConfig = {
    disableClose: false,
    panelClass: 'custom-overlay-pane-class',
    hasBackdrop: true,
    backdropClass: '',
    // width: '750px',
    // height: '500px',
    position: {
      top: '',
      bottom: '',
      left: '',
      right: ''
    },
    data : {
  
    }
  }