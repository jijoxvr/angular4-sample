import { ByteFormatPipe } from './byte-format.pipe';

describe('ByteFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new ByteFormatPipe();
    expect(pipe).toBeTruthy();
  });
});
