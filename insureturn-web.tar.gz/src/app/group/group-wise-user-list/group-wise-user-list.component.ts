import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-group-wise-user-list',
  templateUrl: './group-wise-user-list.component.html',
  styleUrls: ['./group-wise-user-list.component.css']
})
export class GroupWiseUserListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
