import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-policy-list',
  templateUrl: './policy-list.component.html',
  styleUrls: ['./policy-list.component.css']
})
export class PolicyListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
